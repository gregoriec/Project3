import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.figure import Figure


class Main(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)

        tk.Tk.iconbitmap(self, default="m.ico")
        tk.Tk.wm_title(self, "Idiot Program")

        window = tk.Frame(self)
        window.pack(side="top", fill="both", expand=True)
        window.grid_rowconfigure(0, weight=1)
        window.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (Home, Map, Graph):
            frame = F(window, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(Home)

        menu = tk.Menu(window)
        filemenu = tk.Menu(menu, tearoff=0)
        filemenu.add_command(label="Exit", command=exit)
        menu.add_cascade(label="File", menu=filemenu)
        tk.Tk.config(self, menu=menu)

    def show_frame(self,cont):
        frame = self.frames[cont]

        frame.tkraise()

    def client_exit(self):
        exit()



class Home(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)
        label = ttk.Label(self, text="Home", font=("Verdana",12))
        label.pack(pady=10,padx=10)

        button1 = ttk.Button(self, text="Show Map", command=lambda: controller.show_frame(Map))
        button1.pack()

        button2 = ttk.Button(self, text="Show Graph", command=lambda: controller.show_frame(Graph))
        button2.pack()


class Map(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = ttk.Label(self, text="Map", font=("Verdana",12))
        label.grid(pady=4,padx=5, sticky='w')

        self.columnconfigure(1, weight=1)
        self.columnconfigure(3, pad=7)
        self.rowconfigure(3, weight=1)
        self.rowconfigure(5, pad=7)
        self.Graphbutton = ttk.Button(self,)
        self.Graphbutton.grid(row=2,column=3)
        self.haltenaam = ttk.Label(self, text="Metro", font=("Verdana",12))
        self.haltenaam.grid(row=1, column=3, sticky='w', pady=5)

        load = Image.open("Metrolijn.png")
        render = ImageTk.PhotoImage(load)
        img = tk.Label(self, image=render)
        img.image = render
        img.grid(row=1,column=0, columnspan=2,rowspan=4,padx=5,sticky="nsew")

        homebtn = ttk.Button(self, text="Go Home", command=lambda: controller.show_frame(Home))
        homebtn.grid(row=5, column=0, padx=5)

        def buttons(self, haltebutton, titel): # dit verandert de grafiek button en de titel
            self.Graphbutton.grid_remove()
            self.Graphbutton = haltebutton
            self.Graphbutton.grid(row=2,column=3)
            self.haltenaam.grid_remove()
            self.haltenaam = titel
            self.haltenaam.grid(row=1, column=3, sticky='w', pady=5)

        def halte(event):# Give buttons commands
            if (event.x > 668 and event.x < 688) and (event.y > 363 and event.y < 385): # centraal
                print("clicked at Centraal", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Rotterdam Centraal"), ttk.Label(self, text="Rotterdam Centraal", font=("Verdana",12)))
            elif (event.x > 669 and event.x < 688) and (event.y > 395 and event.y < 416): # stadhuis
                print("clicked at stadhuis", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Stadhuis"), ttk.Label(self, text="Stadhuis", font=("Verdana",12)))
            elif (event.x > 648 and event.x < 717) and (event.y > 447 and event.y < 475): # beurs
                print("clicked at beurs", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Beurs"), ttk.Label(self, text="Beurs", font=("Verdana",12)))
            elif (event.x > 608 and event.x < 648) and (event.y > 441 and event.y < 475): # eendrachtsplein
                print("clicked at eendrachtsplein", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Eendrachtsplein"), ttk.Label(self, text="Eendrachtsplein", font=("Verdana",12)))
            elif (event.x > 580 and event.x < 608) and (event.y > 441 and event.y < 475): # dijkzigt
                print("clicked at dijkzigt", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Dijkzigt"), ttk.Label(self, text="Dijkzigt", font=("Verdana",12)))
            elif (event.x > 552 and event.x < 580) and (event.y > 441 and event.y < 475): # coolhaven
                print("clicked at coolhaven", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Coolhaven"), ttk.Label(self, text="Coolhaven", font=("Verdana",12)))
            elif (event.x > 523 and event.x < 552) and (event.y > 441 and event.y < 475): # delfshaven
                print("clicked at delfshaven", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Delfshaven"), ttk.Label(self, text="Delfshaven", font=("Verdana",12)))
            elif (event.x > 497 and event.x < 523) and (event.y > 441 and event.y < 475): # marconiplein
                print("clicked at marconiplein", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Marconiplein"), ttk.Label(self, text="Marconiplein", font=("Verdana",12)))
            elif (event.x > 453 and event.x < 497) and (event.y > 441 and event.y < 475): # schiedam centrum
                print("clicked at schiedam centrum", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Schiedam Centrum"), ttk.Label(self, text="Schiedam Centrum", font=("Verdana",12)))
            elif (event.x > 739 and event.x < 779) and (event.y > 447 and event.y < 475): # blaak
                print("clicked at blaak", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Blaak"), ttk.Label(self, text="Blaak", font=("Verdana",12)))
            elif (event.x > 664 and event.x < 688) and (event.y > 500 and event.y < 525): # leavehaven
                print("clicked at leavehaven", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Leuvehaven"), ttk.Label(self, text="Leuvehaven", font=("Verdana",12)))
            elif (event.x > 664 and event.x < 688) and (event.y > 525 and event.y < 552): # wilhelminaplein
                print("clicked at wilhelminaplein", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Wilhelminaplein"), ttk.Label(self, text="Wilhelminaplein", font=("Verdana",12)))
            elif (event.x > 664 and event.x < 688) and (event.y > 552 and event.y < 580): # rijnhaven
                print("clicked at rijnhaven", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Rijnhaven"), ttk.Label(self, text="Rijnhaven", font=("Verdana",12)))
            elif (event.x > 664 and event.x < 688) and (event.y > 580 and event.y < 608): # maashaven
                print("clicked at maashaven", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Maashaven"), ttk.Label(self, text="Maashaven", font=("Verdana",12)))
            elif (event.x > 664 and event.x < 688) and (event.y > 608 and event.y < 636): # zuidplein
                print("clicked at zuidplein", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Zuidplein"), ttk.Label(self, text="Zuidplein", font=("Verdana",12)))
            elif (event.x > 664 and event.x < 688) and (event.y > 636 and event.y < 664): # slinge
                print("clicked at slinge", event.x, event.y)
                buttons(self, ttk.Button(self, text="Grafieken Slinge"), ttk.Label(self, text="Slinge", font=("Verdana",12)))

        img.bind("<Button-1>", halte)




class Graph(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = ttk.Label(self, text="Graph", font=("Verdana", 12))
        label.pack(pady=10, padx=10)


        button1 = ttk.Button(self, text="Go Home", command=lambda: controller.show_frame(Home))
        button1.pack()


        f = Figure(figsize=(5,5), dpi=100)
        a = f.add_subplot(111)
        a.plot([1,2,3,4,5,6,7,8],[5,2,3,8,5,6,3,8])


        canvas = FigureCanvasTkAgg(f, self)
        canvas.show()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        toolbar = NavigationToolbar2TkAgg(canvas, self)
        toolbar.update()
        canvas._tkcanvas.pack(side=tk.TOP, fill=tk.BOTH, expand=True)





app = Main()
app.mainloop()
